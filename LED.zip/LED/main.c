#include "reg52.h"
#include "intrins.h"
#include "stdlib.h"
#define uint unsigned int
#define uchar unsigned char

int i,j;

void delay(int s)
{
	while(s--);
}

void LEDl1(int n)       //一个led向左流水一遍
{
	int a=0x01;
	for(i=0;i<n;i++)
	{
		P2=~a;
		a<<=1;
		delay(1000000);
		if(a==0x00)
			a=0x01;
	}
}

void LEDl2_1(int n)   //两个紧挨的led向左流水一遍
{
	int a=0x03;
	for(i=0;i<n;i++)
	{
		P2=~a;
		a=a<<1;
		delay(1000000);
		if(a==0x300)
			a=0x03;
	}
}

void LEDl2_2(int n)   //两个led中间隔一个空向左流水一遍
{
	int a=0x05;
	for(i=0;i<n;i++)
	{
		P2=~a;
		a=a<<1;
		delay(1000000);
		if(a==0x500)
			a=0x05;
	}
}

void LEDl3(int n)   //三个led紧挨向左流水一遍
{
	
	int a=0x07;
	for(i=0;i<n;i++)
	{
		P2=~a;
		a=a<<1;
		delay(1000000);
		if(a==0x700)
			a=0x07;
	}
}

void LEDr1(int n)  //一个led向右
{
	int a=0x80;
	for(i=0;i<n;i++)
	{
		P2=~a;
		a=a>>1;
		delay(1000000);
		if(a==0x00)
			a=0x80;
	}
}

void LEDr2_1(int n)  //两个紧凑led向右
{
	int a=0xc0;
	for(i=0;i<n;i++)
	{
		P2=~a;
		a=a>>1;
		delay(1000000);
		if(a==0x00)
			a=0xc0;
	}
}

void LEDr2_2(int n)  //两个隔开led向右
{
	int a=0xa0;
	for(i=0;i<n;i++)
	{
		P2=~a;
		a=a>>1;
		delay(1000000);
		if(a==0x00)
			a=0xa0;
	}
}

void LEDr3(int n)  //一个led向右
{
	int a=0xe0;
	for(i=0;i<n;i++)
	{
		P2=~a;
		a=a>>1;
		delay(1000000);
		if(a==0x00)
			a=0xe0;
	}
}

void show1()
{
	P2=0xf0;
	delay(1000000);
	P2=0xff;
	delay(1000000);
	P2=0xf0;
	delay(1000000);
	P2=0x0f;
	delay(1000000);
	P2=0x0f;
	delay(1000000);
	P2=0x3c;
	delay(1000000);
	P2=0xff;
	delay(1000000);
	P2=0x3c;
	delay(1000000);
	P2=0x66;
	delay(1000000);
	P2=0x66;
	delay(1000000);
	P2=0xc3;
	delay(1000000);
	P2=0xc3;
	delay(1000000);
	P2=0x81;
	delay(1000000);
	P2=0x81;
}

void final()
{
	i=rand()%9;
		switch(i)
		{
			case 0:
				j=rand()%9;
				LEDl1(j);
				break;
			case 1:
				j=rand()%9;
				LEDl2_1(j);
				break;
			case 2:
				j=rand()%9;
				LEDl2_2(j);
				break;
			case 3:
				j=rand()%9;
				LEDl3(j);
				break;
			case 4:
				j=rand()%9;
				LEDr1(j);
				break;
			case 5:
				j=rand()%9;
				LEDr2_1(j);
				break;
			case 6:
				j=rand()%9;
				LEDr2_2(j);
				break;
			case 7:
				j=rand()%9;
				LEDr3(j);
				break;
			case 8:
				show1();
			break;
		}
}

void main()
{
	while(1)
	{
		final();
	}
}